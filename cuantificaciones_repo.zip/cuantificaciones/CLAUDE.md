# Cuantificaciones de obra — reglas del proyecto

Usuario: Chris, Analista de Presupuestos / Ingeniero de Costos (Guatemala). Nivel técnico intermedio-avanzado.
Moneda: quetzales (Q). Responde siempre en español, directo y profesional, sin saludos ni relleno.

## Principios
- Prioridad: exactitud > verificación independiente > trazabilidad > velocidad.
- No inventes datos (precios, cantidades, dimensiones, rendimientos, normas, numerales). Si falta un dato indispensable, pregúntalo; si se puede avanzar con un supuesto razonable, decláralo.
- No asumas que los datos del usuario son correctos. Si detectas un error, dilo y corrígelo.
- No afirmes haber verificado o modificado algo que no hiciste.
- Etiqueta lo relevante: [Dato], [Supuesto], [Cálculo], [Recomendación].

## Archivos
- `entrada/` = originales (DXF, PDF, Excel). NUNCA se modifican ni se sobrescriben.
- `salida/` = copias versionadas (`_v2`, `_rev`, fecha).
- `scripts/` = extractores en Python (ezdxf, openpyxl).
- Analiza primero, modifica después, verifica al final. Cambio quirúrgico = tocar solo lo pedido.
- Al entregar reporta: archivo original y final, hojas/rangos afectados, cambios, verificaciones, errores que permanecen y limitaciones.
- El detalle largo (listados de entidades) va a CSV/Excel en disco, no al chat.

## Cuantificación
- Prioriza geometría y datos estructurados (capas, bloques, atributos, polilíneas, cotas) sobre interpretación visual.
- Cruza plantas, secciones, detalles, cuadros y notas; señala discrepancias.
- Cada cantidad lleva: elemento, ubicación, unidad, cantidad, método, fuente, observaciones.
- Distingue cantidad teórica, cantidad presupuestable y cantidad de compra. Separa lo verificado de lo estimado.
- Revisa alcance, renglones, unidades, omisiones y dobles conteos.
- Acero: varillas comerciales de 6.00 m salvo indicación contraria. Considera ganchos, anclajes, traslapes, optimización de cortes y remanentes. Peso en kg y qq; alambre de amarre en libras.
- Al redactar renglones: corrige ortografía y ordena según secuencia constructiva.

## Excel
- Antes de modificar: revisar dependencias entre hojas, referencias rotas, errores (#REF!, #N/A, #DIV/0!), hardcodes, unidades y duplicados.
- Archivos nuevos: Arial 10, negro, texto centrado. En archivos existentes respeta el formato que traen.
- Unidades en su propia columna o encabezado, nunca mezcladas con el valor.
- Redondeo solo en presentación o cantidad de compra, nunca en cálculos intermedios.
- Fórmulas clásicas (sin LET/XLOOKUP/FILTER) salvo que se confirme la versión de Excel del destinatario.

## Estructural
- ACI 318 y NSE de AGIES (edición que indique el proyecto). No cites numerales que no puedas confirmar.

## Agentes
- `cuantificador-dxf`: inventario y extracción desde DXF a Excel de control.
- `revisor-qaqc`: verificación independiente del Excel contra el DXF. Es paso obligatorio antes de entregar.
