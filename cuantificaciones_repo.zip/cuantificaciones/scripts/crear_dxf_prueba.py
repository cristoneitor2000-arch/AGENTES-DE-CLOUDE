#!/usr/bin/env python3
"""Genera un DXF sintético con cantidades conocidas para probar el extractor."""
import sys

import ezdxf

doc = ezdxf.new("R2010", setup=True)
doc.header["$INSUNITS"] = 6  # metros
doc.layers.add("CIMIENTO"); doc.layers.add("LOSA"); doc.layers.add("ZAPATA")
msp = doc.modelspace()
# Cimiento: polilínea abierta de 10 + 5 = 15.00 m
msp.add_lwpolyline([(0, 0), (10, 0), (10, 5)], dxfattribs={"layer": "CIMIENTO"})
# Losa: contorno cerrado 6 x 4 -> área 24.00, perímetro 20.00
msp.add_lwpolyline([(0, 0), (6, 0), (6, 4), (0, 4)], close=True, dxfattribs={"layer": "LOSA"})
# Zapatas: bloque con atributo, 3 inserciones
b = doc.blocks.new("Z1")
b.add_lwpolyline([(-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)], close=True)
b.add_attdef("MARCA", (0, 0))
for i, x in enumerate((0, 5, 10)):
    ins = msp.add_blockref("Z1", (x, -3), dxfattribs={"layer": "ZAPATA"})
    ins.add_auto_attribs({"MARCA": f"Z-{i+1}"})
# Objeto en capa 0 (debe avisar)
msp.add_line((0, 0), (3, 4))  # longitud 5.00
doc.saveas(sys.argv[1] if len(sys.argv) > 1 else "entrada/prueba_sintetica.dxf")
