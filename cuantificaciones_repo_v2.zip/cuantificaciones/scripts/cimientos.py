#!/usr/bin/env python3
"""Cuantificación de cimentación desde DXF con la convención de capas de Chris.

Uso: python3 scripts/cimientos.py entrada/plano.dxf [--salida salida] [--version v1] [--escala F]

Convención de capas (la medida va en el nombre de la capa):
  "LOCAL 3 Cimiento corrido CC01 de 0.40 × 0.20 m"      -> polilíneas ABIERTAS; ancho × alto (peralte)
  "LOCAL 3 Zapata Z1 de 1.00 × 1.00 × 0.30 m"           -> bloques (INSERT); largo × ancho × espesor
Trazo sin traslapes: cada cimiento termina en la cara de la zapata / cimiento que lo cruza,
por eso NO se descuentan intersecciones. El script lo VERIFICA con geometría (shapely) y
avisa si hay traslapes (concreto duplicado).

Método: por geometría CAD (polilíneas trazadas a cara, sin traslape). El DXF original no se modifica.
Salida: Excel con fórmulas vivas (Parámetros, Generador, Resumen, Control, Advertencias) + CSV de detalle.
"""
import argparse
import csv
import math
import os
import re
import sys
from collections import defaultdict

import ezdxf
from ezdxf import bbox as ezbbox
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.workbook.defined_name import DefinedName
from shapely.geometry import LineString, box
from shapely.ops import unary_union

PAT = re.compile(
    r"^(?P<local>.+?)\s+(?P<tipo>Cimiento corrido|Zapata)\s+(?P<cod>\S+)\s+de\s+(?P<dims>[\d.,\s×xX]+?)\s*m\s*$",
    re.IGNORECASE,
)
TOL_TRASLAPE = 1e-4   # m² de traslape tolerado (ruido numérico)
TOL_DIM = 0.01        # m, tolerancia al comparar medidas de capa vs geometría


def parsea_capa(nombre):
    m = PAT.match(nombre.strip())
    if not m:
        return None
    nums = [float(n.replace(",", ".")) for n in re.split(r"[×xX]", m["dims"]) if n.strip()]
    tipo = "cimiento" if m["tipo"].lower().startswith("cimiento") else "zapata"
    if (tipo == "cimiento" and len(nums) != 2) or (tipo == "zapata" and len(nums) != 3):
        return None
    return {"local": m["local"].strip().upper(), "tipo": tipo, "cod": m["cod"], "dims": nums}


def puntos_poli(e):
    if e.dxftype() == "LWPOLYLINE":
        raw = list(e.get_points("xyb"))
        return [(p[0], p[1]) for p in raw], bool(e.closed), any(abs(p[2]) > 1e-9 for p in raw)
    raw = [(v.dxf.location.x, v.dxf.location.y, v.dxf.bulge) for v in e.vertices]
    return [(p[0], p[1]) for p in raw], bool(e.is_closed), any(abs(p[2]) > 1e-9 for p in raw)


def extraer(ruta, escala):
    doc = ezdxf.readfile(ruta)
    insunits = doc.header.get("$INSUNITS", 0)
    if escala is None:
        if insunits != 6:
            sys.exit(f"ERROR: $INSUNITS = {insunits}, no es metros (6). Confirma la unidad y vuelve a correr con --escala "
                     f"(factor a metros, p. ej. 0.001 para mm).")
        escala = 1.0
    msp = doc.modelspace()
    elementos, advert, ignoradas = [], [], defaultdict(int)
    for e in msp:
        capa = e.dxf.layer
        info = parsea_capa(capa)
        if info is None:
            ignoradas[(capa, e.dxftype())] += 1
            continue
        t = e.dxftype()
        rec = {"capa": capa, "handle": e.dxf.handle, **info, "geom": None, "longitud": None, "obs": ""}
        if info["tipo"] == "cimiento":
            if t not in ("LWPOLYLINE", "POLYLINE", "LINE"):
                advert.append(f"Capa '{capa}': entidad {t} (handle {e.dxf.handle}) no es polilínea; no cuantificada.")
                continue
            if t == "LINE":
                pts = [(e.dxf.start.x * escala, e.dxf.start.y * escala), (e.dxf.end.x * escala, e.dxf.end.y * escala)]
                cerrada, arcos = False, False
            else:
                pts, cerrada, arcos = puntos_poli(e)
                pts = [(x * escala, y * escala) for x, y in pts]
            if cerrada:
                advert.append(f"Capa '{capa}': polilínea CERRADA (handle {e.dxf.handle}); un cimiento corrido debe ser polilínea abierta. No cuantificada.")
                continue
            if len(pts) < 2:
                advert.append(f"Capa '{capa}': polilínea con menos de 2 vértices (handle {e.dxf.handle}).")
                continue
            if arcos:
                rec["obs"] = "tiene arcos (bulge): longitud por cuerdas, subestima"
                advert.append(f"Capa '{capa}': polilínea con arcos (handle {e.dxf.handle}); longitud medida por cuerdas, subestima.")
            ls = LineString(pts)
            rec["longitud"], rec["geom"] = ls.length, ls
            cw = getattr(e.dxf, "const_width", 0) if t == "LWPOLYLINE" else 0
            if cw and abs(cw * escala - info["dims"][0]) > TOL_DIM:
                advert.append(f"Capa '{capa}': ancho de la polilínea ({cw*escala:.3f} m) ≠ ancho del nombre de capa ({info['dims'][0]:.3f} m) (handle {e.dxf.handle}).")
        else:
            if t != "INSERT":
                advert.append(f"Capa '{capa}': entidad {t} (handle {e.dxf.handle}) no es bloque; las zapatas se cuentan por bloque. No cuantificada.")
                continue
            bb = ezbbox.extents(e.virtual_entities())
            l_, a_, _ = info["dims"]
            if bb.has_data:
                x0, y0, x1, y1 = bb.extmin.x * escala, bb.extmin.y * escala, bb.extmax.x * escala, bb.extmax.y * escala
                rec["geom"] = box(x0, y0, x1, y1)
                dl, da = x1 - x0, y1 - y0
                if not ((abs(dl - l_) <= TOL_DIM and abs(da - a_) <= TOL_DIM) or (abs(dl - a_) <= TOL_DIM and abs(da - l_) <= TOL_DIM)):
                    advert.append(f"Capa '{capa}': bloque de {dl:.3f} × {da:.3f} m ≠ medida del nombre de capa {l_:.2f} × {a_:.2f} m (handle {e.dxf.handle}).")
            else:
                cx, cy = e.dxf.insert.x * escala, e.dxf.insert.y * escala
                rec["geom"] = box(cx - l_ / 2, cy - a_ / 2, cx + l_ / 2, cy + a_ / 2)
                rec["obs"] = "bloque sin geometría: se asume centrado en el punto de inserción"
                advert.append(f"Capa '{capa}': bloque sin geometría (handle {e.dxf.handle}); verificación de traslape asume zapata centrada en la inserción.")
        elementos.append(rec)
    return doc, insunits, escala, elementos, advert, ignoradas


def geom_en_planta(r):
    """Polígono en planta del elemento (cimiento = buffer plano de ancho/2)."""
    if r["tipo"] == "cimiento":
        return r["geom"].buffer(r["dims"][0] / 2, cap_style=2, join_style=2)
    return r["geom"]


def traslapes(elementos):
    out = []
    pol = [(r, geom_en_planta(r)) for r in elementos if r["geom"] is not None]
    for i in range(len(pol)):
        for j in range(i + 1, len(pol)):
            ri, gi = pol[i]
            rj, gj = pol[j]
            if not gi.intersects(gj):
                continue
            a = gi.intersection(gj).area
            if a > TOL_TRASLAPE:
                out.append((ri, rj, a))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dxf")
    ap.add_argument("--salida", default="salida")
    ap.add_argument("--version", default="v1")
    ap.add_argument("--escala", type=float, default=None, help="factor a metros si $INSUNITS no es 6")
    a = ap.parse_args()

    doc, insunits, escala, elems, advert, ignoradas = extraer(a.dxf, a.escala)
    if not elems:
        sys.exit("No se encontraron capas con la convención 'LOCAL n Cimiento corrido CCxx de a × h m' / 'Zapata Zx de l × a × h m'.")
    nombre = os.path.splitext(os.path.basename(a.dxf))[0]
    fuente = os.path.basename(a.dxf)
    os.makedirs(a.salida, exist_ok=True)

    # --- agregado por capa
    capas = {}
    for r in elems:
        g = capas.setdefault(r["capa"], {"local": r["local"], "tipo": r["tipo"], "cod": r["cod"], "dims": r["dims"], "n": 0, "L": 0.0})
        g["n"] += 1
        g["L"] += r["longitud"] or 0.0

    def clave(item):
        c, g = item
        m = re.search(r"\d+", g["local"])
        return (int(m.group()) if m else 0, g["local"], 0 if g["tipo"] == "cimiento" else 1, g["cod"])
    orden = sorted(capas.items(), key=clave)

    # --- traslapes y control geométrico
    tr = traslapes(elems)
    for ri, rj, ar in tr:
        advert.append(f"TRASLAPE {ar:.4f} m² entre '{ri['capa']}' (h {ri['handle']}) y '{rj['capa']}' (h {rj['handle']}): concreto duplicado; recorta el trazo a la cara.")
    area_geom = unary_union([geom_en_planta(r) for r in elems if r["geom"] is not None]).area
    for (c, t), n in sorted(ignoradas.items()):
        if c not in ("0", "00", "Defpoints"):
            advert.append(f"Capa '{c}' ({t} ×{n}) no sigue la convención de nombre; NO cuantificada.")
    locales_sin_cim = {g["local"] for _, g in orden if g["tipo"] == "zapata"} - {g["local"] for _, g in orden if g["tipo"] == "cimiento"}
    for loc in sorted(locales_sin_cim):
        advert.append(f"{loc}: tiene zapatas pero ningún cimiento corrido (verificar que sea correcto).")

    # --- CSV de detalle
    ruta_csv = os.path.join(a.salida, f"{nombre}_cimientos_detalle_{a.version}.csv")
    with open(ruta_csv, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["local", "tipo", "codigo", "capa", "handle", "longitud_m", "dims_m", "obs"])
        for r in elems:
            w.writerow([r["local"], r["tipo"], r["cod"], r["capa"], r["handle"],
                        "" if r["longitud"] is None else r["longitud"], "×".join(f"{d:g}" for d in r["dims"]), r["obs"]])

    # --- Excel
    F = Font(name="Arial", size=10, color="000000")
    FB = Font(name="Arial", size=10, color="000000", bold=True)
    CE = Alignment(horizontal="center", vertical="center", wrap_text=True)
    FILL_IN = PatternFill("solid", fgColor="FFF2CC")
    FILL_H = PatternFill("solid", fgColor="D9D9D9")

    wb = Workbook()

    # Parámetros
    wp = wb.active
    wp.title = "Parámetros"
    wp.append(["Parámetro", "Valor", "Unidad", "Aplica a", "Origen", "Nota"])
    params = [
        ("Desperdicio de concreto", 0, "%", "Concreto", "SIN DEFINIR (0 = bruto igual al neto)", "Llenar con base de costos / indicación. Aplicar UNA sola vez."),
        ("Abundamiento de excavación", 0, "%", "Excavación", "SIN DEFINIR (0 = bote igual al neto)", "Depende del tipo de suelo."),
        ("Profundidad de excavación", None, "m", "Excavación", "PENDIENTE (dato de planos)", "Si queda vacío, la excavación no se calcula."),
        ("Sobreancho de excavación por lado", 0, "m", "Excavación", "SIN DEFINIR (0 = a cara de elemento)", "Holgura de trabajo por cada lado."),
    ]
    nombres = ["p_desp_concreto", "p_abund", "p_prof_exc", "p_sobreancho"]
    for fila, (p, nom) in enumerate(zip(params, nombres), start=2):
        wp.append(list(p))
        if p[2] == "%":
            wp.cell(fila, 2).number_format = "0.0%"
        wp.cell(fila, 2).fill = FILL_IN
        wb.defined_names[nom] = DefinedName(nom, attr_text=f"'Parámetros'!$B${fila}")
    wp.append([])
    wp.append(["Los porcentajes se escriben como %, p. ej. 5%. Un parámetro vacío o en 0 no altera el neto."])

    # Generador
    wg = wb.create_sheet("Generador")
    enc = ["Local", "Elemento", "Código", "Fuente (capa)", "Cant. (und)", "Largo (m)", "Ancho (m)", "Alto / Esp. (m)",
           "Descuento", "Fórmula (concreto)", "Concreto neto (m³)", "Formaleta lateral (m²)", "Excavación neta (m³)"]
    wg.append(enc)
    fila0 = 2
    for i, (capa, g) in enumerate(orden):
        f = fila0 + i
        if g["tipo"] == "cimiento":
            ancho, alto = g["dims"]
            wg.append([g["local"], "Cimiento corrido", g["cod"], capa, g["n"], g["L"], ancho, alto, "sin descuento (trazo a cara)",
                       "Largo × Ancho × Alto", f"=F{f}*G{f}*H{f}", f"=2*F{f}*H{f}",
                       f'=IF(N(p_prof_exc)>0,F{f}*(G{f}+2*p_sobreancho)*p_prof_exc,"")'])
        else:
            l_, an, h = g["dims"]
            wg.append([g["local"], "Zapata", g["cod"], capa, g["n"], l_, an, h, "—",
                       "Cant. × L × A × Esp.", f"=E{f}*F{f}*G{f}*H{f}", f"=E{f}*2*(F{f}+G{f})*H{f}",
                       f'=IF(N(p_prof_exc)>0,E{f}*(F{f}+2*p_sobreancho)*(G{f}+2*p_sobreancho)*p_prof_exc,"")'])
    ult = fila0 + len(orden) - 1
    ft = ult + 1
    wg.append(["TOTAL", "", "", "", "", "", "", "", "", "", f"=SUM(K{fila0}:K{ult})", f"=SUM(L{fila0}:L{ult})",
               f'=IF(N(p_prof_exc)>0,SUM(M{fila0}:M{ult}),"")'])
    wg.append([])
    wg.append(["Notas: Largo de cimiento = suma de longitudes de polilíneas de la capa (valor extraído del DXF, fuente en CSV por handle). "
               "Formaleta lateral = 2 caras × largo × alto; no incluye fondo (colado contra suelo) ni descuenta caras contiguas en cruces."])

    # Resumen por local
    wr = wb.create_sheet("Resumen")
    wr.append(["Local", "Cimiento corrido (m)", "Concreto cimiento (m³)", "Zapatas (und)", "Concreto zapatas (m³)",
               "Concreto neto (m³)", "Desperdicio (%)", "Concreto bruto (m³)", "Formaleta lateral (m²)"])
    locales = []
    for _, g in orden:
        if g["local"] not in locales:
            locales.append(g["local"])
    rng = lambda col: f"Generador!${col}${fila0}:${col}${ult}"
    for i, loc in enumerate(locales):
        f = 2 + i
        wr.append([loc,
                   f'=SUMIFS({rng("F")},{rng("A")},$A{f},{rng("B")},"Cimiento corrido")',
                   f'=SUMIFS({rng("K")},{rng("A")},$A{f},{rng("B")},"Cimiento corrido")',
                   f'=SUMIFS({rng("E")},{rng("A")},$A{f},{rng("B")},"Zapata")',
                   f'=SUMIFS({rng("K")},{rng("A")},$A{f},{rng("B")},"Zapata")',
                   f"=C{f}+E{f}", "=p_desp_concreto", f"=F{f}*(1+G{f})",
                   f'=SUMIFS({rng("L")},{rng("A")},$A{f})'])
    fu = 1 + len(locales)
    wr.append(["TOTAL"] + [f"=SUM({c}2:{c}{fu})" for c in "BCDEF"] + ["=p_desp_concreto", f"=SUM(H2:H{fu})", f"=SUM(I2:I{fu})"])
    wr.append([])
    wr.append(["Cantidad NETA salvo la columna 'bruto' (desperdicio de Parámetros). Cantidad comercial (m³ de pedido) pendiente: depende del incremento del proveedor."])

    # Control
    wc = wb.create_sheet("Control")
    wc.append(["Control", "Valor", "Unidad", "Método"])
    wc.append(["Área en planta por generador (Σ L×ancho + Σ zapatas)",
               f'=SUMPRODUCT(({rng("B")}="Cimiento corrido")*{rng("F")}*{rng("G")})+SUMPRODUCT(({rng("B")}="Zapata")*{rng("E")}*{rng("F")}*{rng("G")})',
               "m²", "Fórmulas del Generador"])
    wc.append(["Área en planta por geometría CAD (unión de polígonos)", area_geom, "m²", "shapely: unión de buffers de polilíneas y bloques"])
    wc.append(["Diferencia", "=B2-B3", "m²", "Debe ser ≈ 0; ≠ 0 indica traslape, elemento omitido o ancho inconsistente"])
    wc.append(["Estado", '=IF(ABS(B4)<0.001,"CUADRA","REVISAR")', "", "Tolerancia 0.001 m²"])

    # Advertencias
    wa = wb.create_sheet("Advertencias")
    wa.append(["#", "Advertencia / pendiente"])
    base = [
        f"Fuente: {fuente}; $INSUNITS = {insunits}; escala a metros = {escala:g}.",
        "Método de intersecciones: por geometría CAD (trazo a cara, sin traslape). No se descuentan cruces; se verifica con shapely (hoja Control).",
        "Zapatas bajo cimiento: con trazo a cara no hay concreto duplicado; no se descuenta volumen.",
        "Parámetros de desperdicio, abundamiento y profundidad de excavación SIN DEFINIR: el resultado es neto hasta que se llenen.",
        "Formaleta lateral no descuenta caras contiguas en cruces/encuentros (sobreestima ligeramente).",
        "Acero de refuerzo NO incluido (usar cuantificador-acero-refuerzo).",
    ]
    for i, t in enumerate(base + advert, start=1):
        wa.append([i, t])

    # formato
    anchos = {"Parámetros": [34, 12, 10, 14, 36, 52], "Generador": [12, 18, 10, 48, 11, 11, 11, 13, 26, 26, 16, 18, 18],
              "Resumen": [12, 18, 18, 14, 18, 16, 14, 16, 18], "Control": [52, 14, 10, 60], "Advertencias": [6, 140]}
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                c.font, c.alignment = F, CE
        for c in ws[1]:
            c.font, c.fill = FB, FILL_H
        for k, wdt in enumerate(anchos[ws.title], start=1):
            ws.column_dimensions[ws.cell(1, k).column_letter].width = wdt
    wa.column_dimensions["B"].width = 140
    for row in wa.iter_rows(min_row=2, min_col=2, max_col=2):
        for c in row:
            c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    for ws, cols in ((wg, "FGHKLM"), (wr, "BCEFHI"), (wc, "B")):
        for row in ws.iter_rows(min_row=2):
            for c in row:
                if c.column_letter in cols:
                    c.number_format = "0.000"
    for row in wg.iter_rows(min_row=2, min_col=5, max_col=5):
        for c in row:
            c.number_format = "0"
    for c in wg[ft] + wr[fu + 1]:
        c.font = FB
    wb.move_sheet("Parámetros", offset=0)

    ruta_xlsx = os.path.join(a.salida, f"{nombre}_cimientos_{a.version}.xlsx")
    wb.save(ruta_xlsx)

    # --- consola
    print(f"Archivo: {a.dxf} | $INSUNITS={insunits} | escala={escala:g} | entidades cuantificadas: {len(elems)}")
    for capa, g in orden:
        medida = f"{g['L']:.3f} m (n={g['n']})" if g["tipo"] == "cimiento" else f"{g['n']} und"
        print(f"  {capa}: {medida}")
    print(f"Área en planta (geometría): {area_geom:.4f} m² | traslapes: {len(tr)} | advertencias: {len(advert)}")
    for t in advert:
        print("  AVISO:", t)
    print(f"Excel: {ruta_xlsx}\nCSV:   {ruta_csv}")


if __name__ == "__main__":
    main()
