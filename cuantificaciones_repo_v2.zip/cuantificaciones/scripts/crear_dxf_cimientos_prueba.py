#!/usr/bin/env python3
"""DXF sintético de cimentación con la convención de capas. Uso: crear_dxf_cimientos_prueba.py salida.dxf [--con-errores]
Valores esperados (sin errores): LOCAL 1 CC01 9.000 m, CC02 5.800 m, Z1 2; LOCAL 2 CC01 4.000 m, Z1 2."""
import sys
import ezdxf

ruta = sys.argv[1]
errores = "--con-errores" in sys.argv
doc = ezdxf.new("R2010")
doc.header["$INSUNITS"] = 6
c1 = "LOCAL 1 Cimiento corrido CC01 de 0.40 × 0.20 m"
c2 = "LOCAL 1 Cimiento corrido CC02 de 0.40 × 0.20 m"
z1 = "LOCAL 1 Zapata Z1 de 1.00 × 1.00 × 0.30 m"
d1 = "LOCAL 2 Cimiento corrido CC01 de 0.40 × 0.20 m"
dz = "LOCAL 2 Zapata Z1 de 1.00 × 1.00 × 0.30 m"
for n in (c1, c2, z1, d1, dz, "00", "ROTULO"):
    doc.layers.add(n)
b = doc.blocks.new("Z1")
b.add_lwpolyline([(-.5, -.5), (.5, -.5), (.5, .5), (-.5, .5)], close=True)
msp = doc.modelspace()
for x in (0, 10):
    msp.add_blockref("Z1", (x, 0), dxfattribs={"layer": z1})
for x in (20, 25):
    msp.add_blockref("Z1", (x, 0), dxfattribs={"layer": dz})
msp.add_lwpolyline([(0.5, 0), (9.5, 0)], dxfattribs={"layer": c1})                 # 9.000
msp.add_lwpolyline([(5, 6 if not errores else 6), (5, 0.2 if not errores else 0)], dxfattribs={"layer": c2})  # 5.800 (o 6.000 con traslape)
msp.add_lwpolyline([(20.5, 0), (24.5, 0)], dxfattribs={"layer": d1})               # 4.000
msp.add_text("ROTULO", dxfattribs={"layer": "ROTULO"})
if errores:
    msp.add_lwpolyline([(0, 3), (2, 3), (2, 5), (0, 5)], close=True, dxfattribs={"layer": c1})  # cerrada en capa de cimiento
    msp.add_blockref("Z1", (30, 0), dxfattribs={"layer": "LOCAL 2 Zapata Z1 de 1.20 × 1.20 × 0.30 m"})  # bloque 1.0 vs nombre 1.2
doc.saveas(ruta)
