#!/usr/bin/env python3
"""Extractor base por capas desde DXF -> Excel de control + CSV de detalle.

Uso: python3 scripts/extraer_dxf.py entrada/plano.dxf [--salida salida] [--version v1]

Método por tipo de entidad (el original NO se modifica):
  LINE            -> longitud
  LWPOLYLINE/POLYLINE abierta  -> longitud
  LWPOLYLINE/POLYLINE cerrada  -> perímetro y área (fórmula de Gauss; arcos con bulge aproximados por su cuerda -> se marca en observaciones)
  CIRCLE          -> área y perímetro
  INSERT          -> conteo por nombre de bloque (+ atributos en CSV)
Las unidades salen de $INSUNITS; si no están definidas, se declara y NO se convierte.
"""
import argparse
import csv
import math
import os
import sys
from collections import defaultdict

import ezdxf
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font

UNIDADES = {0: "sin definir", 1: "in", 2: "ft", 4: "mm", 5: "cm", 6: "m"}
A_METROS = {4: 0.001, 5: 0.01, 6: 1.0}  # factores a metros (solo unidades métricas)


def _pts(e):
    """Devuelve (puntos[(x,y)], cerrada, tiene_arcos)."""
    if e.dxftype() == "LWPOLYLINE":
        pts = [(p[0], p[1]) for p in e.get_points("xyb")]
        arcos = any(abs(p[2]) > 1e-9 for p in e.get_points("xyb"))
        return pts, bool(e.closed), arcos
    pts = [(v.dxf.location.x, v.dxf.location.y) for v in e.vertices]
    arcos = any(abs(v.dxf.bulge) > 1e-9 for v in e.vertices)
    return pts, bool(e.is_closed), arcos


def _long(pts, cerrada):
    n = len(pts)
    seg = n if cerrada else n - 1
    return sum(math.dist(pts[i], pts[(i + 1) % n]) for i in range(seg))


def _area(pts):
    n = len(pts)
    return abs(sum(pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1] for i in range(n))) / 2


def extraer(ruta):
    doc = ezdxf.readfile(ruta)
    msp = doc.modelspace()
    insunits = doc.header.get("$INSUNITS", 0)
    filas = []
    for e in msp:
        t = e.dxftype()
        capa = e.dxf.layer
        base = {"capa": capa, "tipo": t, "handle": e.dxf.handle, "bloque": "", "longitud": None,
                "perimetro": None, "area": None, "conteo": None, "obs": ""}
        if t == "LINE":
            base["longitud"] = math.dist((e.dxf.start.x, e.dxf.start.y), (e.dxf.end.x, e.dxf.end.y))
        elif t in ("LWPOLYLINE", "POLYLINE"):
            pts, cerrada, arcos = _pts(e)
            if len(pts) < 2:
                base["obs"] = "menos de 2 vértices"
            elif cerrada:
                base["perimetro"] = _long(pts, True)
                base["area"] = _area(pts)
            else:
                base["longitud"] = _long(pts, False)
            if arcos:
                base["obs"] = "tiene arcos (bulge): medido por cuerdas, subestima"
        elif t == "CIRCLE":
            r = e.dxf.radius
            base["perimetro"], base["area"] = 2 * math.pi * r, math.pi * r * r
        elif t == "INSERT":
            base["bloque"] = e.dxf.name
            base["conteo"] = 1
            attrs = {a.dxf.tag: a.dxf.text for a in e.attribs}
            if attrs:
                base["obs"] = "attr: " + "; ".join(f"{k}={v}" for k, v in attrs.items())
        else:
            base["obs"] = "tipo no cuantificado"
        filas.append(base)
    return doc, insunits, filas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dxf")
    ap.add_argument("--salida", default="salida")
    ap.add_argument("--version", default="v1")
    a = ap.parse_args()

    doc, insunits, filas = extraer(a.dxf)
    uni = UNIDADES.get(insunits, f"código {insunits}")
    factor = A_METROS.get(insunits)
    nombre = os.path.splitext(os.path.basename(a.dxf))[0]
    os.makedirs(a.salida, exist_ok=True)

    # --- Inventario en consola (compacto)
    capas = defaultdict(lambda: defaultdict(int))
    for f in filas:
        capas[f["capa"]][f["tipo"]] += 1
    print(f"Archivo: {a.dxf} | $INSUNITS = {insunits} ({uni}) | entidades en modelo: {len(filas)}")
    if factor is None:
        print("AVISO: unidades no métricas o sin definir; las cantidades salen en unidades de dibujo SIN convertir.")
    for c in sorted(capas):
        print(f"  {c}: " + ", ".join(f"{t}={n}" for t, n in sorted(capas[c].items())))
    if "0" in capas:
        print("AVISO: hay objetos en la capa 0.")

    # --- CSV de detalle
    ruta_csv = os.path.join(a.salida, f"{nombre}_detalle_{a.version}.csv")
    cols = ["capa", "tipo", "handle", "bloque", "longitud", "perimetro", "area", "conteo", "obs"]
    with open(ruta_csv, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows([{k: f[k] for k in cols} for f in filas])

    # --- Excel de control (resumen por capa; valores crudos del DXF, sin redondeo)
    f_ = Font(name="Arial", size=10, color="000000")
    fb = Font(name="Arial", size=10, color="000000", bold=True)
    ce = Alignment(horizontal="center", vertical="center", wrap_text=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "Resumen"
    enc = ["Elemento (capa)", "Ubicación", "Tipo de entidad", "Unidad", "Cantidad", "Método", "Fuente", "Observaciones"]
    ws.append(enc)
    u_dib = "u.d." if factor is None else "m"
    agg = defaultdict(lambda: {"n": 0, "L": 0.0, "P": 0.0, "A": 0.0, "obs": set()})
    for f in filas:
        k = (f["capa"], f["tipo"], f["bloque"])
        g = agg[k]
        g["n"] += 1
        g["L"] += (f["longitud"] or 0) * (factor or 1)
        g["P"] += (f["perimetro"] or 0) * (factor or 1)
        g["A"] += (f["area"] or 0) * (factor or 1) ** 2
        if f["obs"] and not f["obs"].startswith("attr:"):
            g["obs"].add(f["obs"])
    fuente = os.path.basename(a.dxf)
    for (capa, tipo, bloque), g in sorted(agg.items()):
        nom = f"{capa} / {bloque}" if bloque else capa
        obs = "; ".join(sorted(g["obs"]))
        if tipo == "INSERT":
            ws.append([nom, capa, tipo, "und", g["n"], "conteo de bloques", fuente, obs])
        elif tipo in ("LWPOLYLINE", "POLYLINE"):
            if g["L"]:
                ws.append([nom, capa, tipo + " abierta", u_dib, g["L"], "suma de longitudes", fuente, obs])
            if g["A"]:
                ws.append([nom, capa, tipo + " cerrada", u_dib + "²", g["A"], "suma de áreas (Gauss)", fuente, obs])
                ws.append([nom, capa, tipo + " cerrada", u_dib, g["P"], "suma de perímetros", fuente, obs])
        elif tipo == "LINE":
            ws.append([nom, capa, tipo, u_dib, g["L"], "suma de longitudes", fuente, obs])
        elif tipo == "CIRCLE":
            ws.append([nom, capa, tipo, u_dib + "²", g["A"], "suma de áreas", fuente, obs])
        else:
            ws.append([nom, capa, tipo, "und", g["n"], "conteo (no cuantificado)", fuente, obs])

    ws2 = wb.create_sheet("Info")
    for r in [["Archivo fuente", fuente], ["$INSUNITS", insunits], ["Unidades del dibujo", uni],
              ["Conversión a metros", "sí" if factor else "NO (sin convertir)"],
              ["Entidades en modelo", len(filas)], ["Detalle por entidad", os.path.basename(ruta_csv)],
              ["Nota", "Cantidades teóricas desde geometría; sin desperdicios ni factores de compra."]]:
        ws2.append(r)

    for hoja in (ws, ws2):
        for row in hoja.iter_rows():
            for c in row:
                c.font, c.alignment = f_, ce
        for col in hoja.columns:
            hoja.column_dimensions[col[0].column_letter].width = 24
    for c in ws[1]:
        c.font = fb
    for row in ws.iter_rows(min_row=2, min_col=5, max_col=5):
        for c in row:
            c.number_format = "0.000"

    ruta_xlsx = os.path.join(a.salida, f"{nombre}_cuantificacion_{a.version}.xlsx")
    wb.save(ruta_xlsx)
    print(f"Excel: {ruta_xlsx}\nCSV:   {ruta_csv}")


if __name__ == "__main__":
    sys.exit(main())
